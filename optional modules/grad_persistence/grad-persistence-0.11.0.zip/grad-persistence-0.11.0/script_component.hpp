#define PREFIX grad
#define COMPONENT persistence

#include "\x\cba\addons\main\script_macros.hpp"
/* #include "\z\ace\addons\main\script_macros.hpp" */
